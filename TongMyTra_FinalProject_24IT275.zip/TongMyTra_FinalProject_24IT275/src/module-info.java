/**
 * 
 */
/**
 * 
 */
module TongMyTra_FinalProject_24IT275 {
	requires java.desktop;
	requires java.sql;

}