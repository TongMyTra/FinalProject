package Model;

import java.util.Objects;

public class Ticket {
	private int ticketID;
	private String busName;
	private Customer customerName;
	private String seat;
	private float price;
	private String date;
	private String destination;
	public Ticket() {
		
	}
	public Ticket(int ticketID, String busName, Customer customerName, String seat, float price, String date,
			String destination) {
		
		this.ticketID = ticketID;
		this.busName = busName;
		this.customerName = customerName;
		this.seat = seat;
		this.price = price;
		this.date = date;
		this.destination = destination;
	}
	public int getTicketID() {
		return ticketID;
	}
	public void setTicketID(int ticketID) {
		this.ticketID = ticketID;
	}
	public String getBusName() {
		return busName;
	}
	public void setBusName(String busName) {
		this.busName = busName;
	}
	public Customer getCustomerName() {
		return customerName;
	}
	public void setCustomerName(Customer customerName) {
		this.customerName = customerName;
	}
	public String getSeat() {
		return seat;
	}
	public void setSeat(String seat) {
		this.seat = seat;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	@Override
	public String toString() {
		return "Ticket [ticketID=" + ticketID + ", busName=" + busName + ", customerName=" + customerName + ", seat="
				+ seat + ", price=" + price + ", date=" + date + ", destination=" + destination + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(busName, customerName, date, destination, price, seat, ticketID);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ticket other = (Ticket) obj;
		return Objects.equals(busName, other.busName) && Objects.equals(customerName, other.customerName)
				&& Objects.equals(date, other.date) && Objects.equals(destination, other.destination)
				&& Float.floatToIntBits(price) == Float.floatToIntBits(other.price) && Objects.equals(seat, other.seat)
				&& ticketID == other.ticketID;
	}
	
	
}
