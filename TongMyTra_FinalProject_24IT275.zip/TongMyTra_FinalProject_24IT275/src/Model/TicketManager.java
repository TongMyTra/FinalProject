package Model;

import java.net.PortUnreachableException;
import java.util.ArrayList;

import javax.print.attribute.standard.Destination;

public class TicketManager {
	private ArrayList<Ticket> ticket;
	
	public TicketManager() {
		this.ticket = new ArrayList<Ticket>();
	}

	public TicketManager(ArrayList<Ticket> ticket) {
		this.ticket = ticket;
	}

	public ArrayList<Ticket> getTicket() {
		return ticket;
	}

	public void setTicket(ArrayList<Ticket> ticket) {
		this.ticket = ticket;
	}
	
	
	
		
	
}
