package Model;

import java.util.Objects;

public class Customer {
	private int customerID;
	private String name;
	private String phone;
	private String gender;
	private String membership;
	private String adress;
	public Customer(int customerID, String name, String phone, String gender, String membership, String adress) {
		
		this.customerID = customerID;
		this.name = name;
		this.phone = phone;
		this.gender = gender;
		this.membership = membership;
		this.adress = adress;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMembership() {
		return membership;
	}
	public void setMembership(String membership) {
		this.membership = membership;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", name=" + name + ", phone=" + phone + ", gender=" + gender
				+ ", membership=" + membership + ", adress=" + adress + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(adress, customerID, gender, membership, name, phone);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		return Objects.equals(adress, other.adress) && customerID == other.customerID
				&& Objects.equals(gender, other.gender) && Objects.equals(membership, other.membership)
				&& Objects.equals(name, other.name) && Objects.equals(phone, other.phone);
	}
	
	
	
	
}
