package Model;

import java.util.Objects;

public class Bus {
	private int ID;
	private String busName;
	private String lincensePlante;
	private String dateOfRegistration;
	private String status;
	public Bus(int iD, String busName, String lincensePlante, String dateOfRegistration, String status) {
		ID = iD;
		this.busName = busName;
		this.lincensePlante = lincensePlante;
		this.dateOfRegistration = dateOfRegistration;
		this.status = status;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getBusName() {
		return busName;
	}
	public void setBusName(String busName) {
		this.busName = busName;
	}
	public String getLincensePlante() {
		return lincensePlante;
	}
	public void setLincensePlante(String lincensePlante) {
		this.lincensePlante = lincensePlante;
	}
	public String getDateOfRegistration() {
		return dateOfRegistration;
	}
	public void setDateOfRegistration(String dateOfRegistration) {
		this.dateOfRegistration = dateOfRegistration;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public int hashCode() {
		return Objects.hash(ID, busName, dateOfRegistration, lincensePlante, status);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bus other = (Bus) obj;
		return ID == other.ID && Objects.equals(busName, other.busName)
				&& Objects.equals(dateOfRegistration, other.dateOfRegistration)
				&& Objects.equals(lincensePlante, other.lincensePlante) && Objects.equals(status, other.status);
	}
	@Override
	public String toString() {
		return "Bus [ID=" + ID + ", busName=" + busName + ", lincensePlante=" + lincensePlante + ", dateOfRegistration="
				+ dateOfRegistration + ", status=" + status + "]";
	}
	
	
	
	
}
