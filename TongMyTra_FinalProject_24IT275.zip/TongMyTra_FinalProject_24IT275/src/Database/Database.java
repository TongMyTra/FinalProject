package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {
	private static final String DB_ServerName = "DESKTOP-A3HUPIM";
	private static final String DB_Login = "sa";
	private static final String DB_Password = "123456789";
	private static final String DB_Name = "FinalProject";
	
	public static Connection getConnection() {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String DB_URL = "jdbc:sqlserver://" + DB_ServerName + ":1433" + ";databaseName=" + DB_Name +"; encrypt= false; trustServerCertificate= true";
			try {
				return DriverManager.getConnection(DB_URL, DB_Login, DB_Password);
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}
	
}
