package Code;

import java.sql.Connection;

import Database.Database;

public class Main {

	public static void main(String[] args) {
		Connection connect = Database.getConnection();
		if (connect == null) {
			System.out.println("That Bai");
		}else {
			System.out.println("Thanh Cong");
		}
	}
	
	

}

