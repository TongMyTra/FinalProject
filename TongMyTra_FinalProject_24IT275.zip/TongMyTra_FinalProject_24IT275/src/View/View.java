package View;

public class View {

	public static void main(String[] args) {
    	new SignIn();
 //   	new BusManager();
	}

}
